import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Target, Users, ShoppingCart, Star, Search, Menu, X, ChevronRight, Zap, Crosshair } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Soldier {
  id: number;
  name: string;
  rating: number;
  kills: number;
  rank: string;
}

const WEAPONS = [
  {
    id: 1,
    name: 'AK-47 التكتيكي',
    price: '$1,200',
    description: 'الإصدار المطور بدقة عالية وقوة ارتداد منخفضة.',
    image: '/images/ak47.jpg'
  },
  {
    id: 2,
    name: 'M4A1 كاربين',
    price: '$2,500',
    description: 'سلاح النخبة للعمليات الخاصة، دقة لا متناهية.',
    image: 'https://images.unsplash.com/photo-1595590424283-b8f17842773f?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 3,
    name: 'مسدس P226',
    price: '$850',
    description: 'سلاح جانبي موثوق في كافة الظروف الصعبة.',
    image: 'https://images.unsplash.com/photo-1590402021678-8386f917b2b6?auto=format&fit=crop&q=80&w=800'
  }
];

const ARABIC_NAMES = [
  'أحمد المنصور', 'يوسف الحربي', 'عمر الفاروق', 'خالد بن الوليد', 'سيف الدين', 
  'محمد القحطاني', 'علي الشمري', 'صالح الغامدي', 'فهد المطيري', 'بدر العتيبي',
  'سلطان العنزي', 'فيصل الدوسري', 'تركي السبيعي', 'عبد الله التميمي', 'منصور الرشيدي',
  'سعد البقمي', 'مشعل السهلي', 'نايف الظفيري', 'ثامر الرويلي', 'طلال الحارثي',
  'ياسر الشهري', 'ماجد البلوي', 'سلمان القحطاني', 'باسم اليافعي', 'زيد الخالدي',
  'راشد المري', 'حمد السويدي', 'سعيد الكعبي', 'جاسم الحمادي', 'مبارك المهيري'
];

const generateSoldiers = (): Soldier[] => {
  const topThree: Soldier[] = [
    { id: 1, name: 'حمزة ياو', rating: 8, kills: 2450, rank: 'القائد الأعلى' },
    { id: 2, name: 'الهادي يعقوب', rating: 5, kills: 1820, rank: 'نائب القائد' },
    { id: 3, name: 'عزيز المسرف', rating: 5, kills: 1750, rank: 'قائد العمليات' },
  ];

  const others: Soldier[] = Array.from({ length: 80 }, (_, i) => ({
    id: i + 4,
    name: ARABIC_NAMES[Math.floor(Math.random() * ARABIC_NAMES.length)] + ' ' + (i + 1),
    rating: Math.floor(Math.random() * 5) + 1,
    kills: Math.floor(Math.random() * 1000) + 50,
    rank: 'جندي تكتيكي'
  }));

  return [...topThree, ...others];
};

const StarRating = ({ rating, max = 5 }: { rating: number; max?: number }) => {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: max }).map((_, i) => (
        <Star
          key={i}
          size={14}
          className={cn(
            "fill-current",
            i < rating ? "text-yellow-500" : "text-gray-700"
          )}
        />
      ))}
    </div>
  );
};

export default function App() {
  const [soldiers] = useState<Soldier[]>(generateSoldiers());
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSoldiers = soldiers.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 font-sans selection:bg-red-600 selection:text-white overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-red-700 rounded-lg flex items-center justify-center rotate-45 group hover:rotate-90 transition-transform duration-300">
                <Shield className="-rotate-45 group-hover:-rotate-90 transition-transform duration-300 text-white" size={24} />
              </div>
              <span className="text-2xl font-black tracking-tighter uppercase mr-2">تنظيم الدولة التكتيكي</span>
            </div>
            
            <div className="hidden md:flex items-center gap-8 text-sm font-bold">
              <a href="#" className="hover:text-red-500 transition-colors">الرئيسية</a>
              <a href="#weapons" className="hover:text-red-500 transition-colors">ترسانة الأسلحة</a>
              <a href="#leaderboard" className="hover:text-red-500 transition-colors">قائمة الجنود</a>
              <a href="#" className="hover:text-red-500 transition-colors">حول التنظيم</a>
            </div>

            <div className="flex items-center gap-4">
              <button className="p-2 hover:bg-white/5 rounded-full transition-colors">
                <Search size={20} />
              </button>
              <button className="bg-red-700 hover:bg-red-600 px-6 py-2 rounded-full text-sm font-bold transition-all transform hover:scale-105 active:scale-95 flex items-center gap-2">
                <ShoppingCart size={18} />
                <span>المتجر</span>
              </button>
              <button 
                className="md:hidden p-2"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/60 to-transparent z-10" />
          <img 
            src="/images/hero.jpg" 
            alt="Hero Background" 
            className="w-full h-full object-cover scale-105 animate-slow-zoom"
          />
        </div>

        <div className="relative z-20 text-center px-4 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-red-600 font-bold tracking-[0.3em] mb-4 text-sm md:text-base">القوة والاحترافية</h2>
            <h1 className="text-5xl md:text-8xl font-black mb-8 leading-tight">
              نخبة <span className="text-red-700">التنظيم</span> التكتيكي
            </h1>
            <p className="text-lg md:text-xl text-neutral-400 mb-10 max-w-2xl mx-auto leading-relaxed">
              المصدر الأول والموثوق للمعدات التكتيكية والأسلحة المتطورة. نحن نجمع بين القوة والدقة في كل قطعة نوفرها.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
              <a href="#weapons" className="w-full sm:w-auto bg-white text-black px-10 py-4 rounded-full font-black text-lg hover:bg-neutral-200 transition-colors">
                استعرض الترسانة
              </a>
              <a href="#leaderboard" className="w-full sm:w-auto border border-white/20 px-10 py-4 rounded-full font-black text-lg hover:bg-white/10 transition-colors backdrop-blur-sm">
                قائمة النخبة
              </a>
            </div>

            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="inline-block px-6 py-2 border-y border-white/10 text-neutral-500 font-serif italic text-2xl"
            >
              " لا إله إلا الله "
            </motion.div>
          </motion.div>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce opacity-50">
          <div className="w-1 h-12 bg-gradient-to-b from-red-600 to-transparent rounded-full" />
        </div>
      </section>

      {/* Weapons Arsenal */}
      <section id="weapons" className="py-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div>
              <h2 className="text-4xl md:text-6xl font-black mb-4">ترسانة <span className="text-red-700">الأسلحة</span></h2>
              <p className="text-neutral-400 max-w-xl">أحدث ما توصلت إليه التكنولوجيا العسكرية من أسلحة هجومية ومعدات تكتيكية متطورة.</p>
            </div>
            <button className="group flex items-center gap-2 font-bold text-red-500 hover:text-red-400 transition-colors">
              عرض جميع المعدات <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {WEAPONS.map((weapon, idx) => (
              <motion.div
                key={weapon.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="group relative bg-neutral-900 border border-white/5 rounded-3xl overflow-hidden hover:border-red-600/50 transition-all duration-500"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img 
                    src={weapon.image} 
                    alt={weapon.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                </div>
                <div className="p-8">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-2xl font-bold">{weapon.name}</h3>
                    <span className="text-red-500 font-black">{weapon.price}</span>
                  </div>
                  <p className="text-neutral-400 mb-6 text-sm">{weapon.description}</p>
                  <button className="w-full bg-white/5 group-hover:bg-red-700 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2">
                    شراء الآن <ShoppingCart size={18} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Leaderboard Section */}
      <section id="leaderboard" className="py-24 bg-neutral-900/50 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-black mb-4 italic">قائمة <span className="text-red-700">النخبة</span></h2>
            <p className="text-neutral-400">سجل الشرف لأكثر الجنود كفاءة وفتكاً في الميدان.</p>
          </div>

          <div className="bg-neutral-900 rounded-3xl border border-white/5 overflow-hidden shadow-2xl">
            <div className="p-6 border-b border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
                <input 
                  type="text" 
                  placeholder="ابحث عن جندي..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-neutral-800 border-none rounded-xl py-3 px-12 focus:ring-2 focus:ring-red-600 transition-all outline-none"
                />
              </div>
              <div className="flex gap-4">
                <div className="flex items-center gap-2 px-4 py-2 bg-neutral-800 rounded-xl">
                  <Users size={18} className="text-red-500" />
                  <span className="font-bold">{soldiers.length} جندي</span>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 bg-neutral-800 rounded-xl">
                  <Target size={18} className="text-red-500" />
                  <span className="font-bold">مجموع القتلى: 84,200+</span>
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse">
                <thead>
                  <tr className="bg-neutral-950/50 text-neutral-500 text-sm font-bold uppercase tracking-wider">
                    <th className="px-8 py-4">الترتيب</th>
                    <th className="px-8 py-4">الجندي</th>
                    <th className="px-8 py-4 text-center">الرتبة</th>
                    <th className="px-8 py-4 text-center">التقييم</th>
                    <th className="px-8 py-4 text-center">عدد القتلى</th>
                    <th className="px-8 py-4"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  <AnimatePresence>
                    {filteredSoldiers.map((soldier, index) => (
                      <motion.tr 
                        key={soldier.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className={cn(
                          "group hover:bg-white/5 transition-colors duration-200",
                          index < 3 ? "bg-red-900/10" : ""
                        )}
                      >
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-3">
                            {index === 0 && <Zap size={20} className="text-yellow-500 animate-pulse" />}
                            <span className={cn(
                              "text-2xl font-black italic",
                              index < 3 ? "text-red-500" : "text-neutral-700"
                            )}>
                              #{index + 1}
                            </span>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-4">
                            <div className={cn(
                              "w-12 h-12 rounded-full flex items-center justify-center text-xl font-black border-2",
                              index === 0 ? "bg-red-700 border-red-500" : "bg-neutral-800 border-neutral-700"
                            )}>
                              {soldier.name.charAt(0)}
                            </div>
                            <div>
                              <div className="font-bold text-lg group-hover:text-red-500 transition-colors">{soldier.name}</div>
                              <div className="text-xs text-neutral-500 font-medium">معرف: T-00{soldier.id}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-8 py-6 text-center">
                          <span className={cn(
                            "px-3 py-1 rounded-full text-xs font-bold",
                            index === 0 ? "bg-red-700 text-white" : "bg-neutral-800 text-neutral-400"
                          )}>
                            {soldier.rank}
                          </span>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex justify-center">
                            <StarRating rating={soldier.rating} max={soldier.rating > 5 ? soldier.rating : 5} />
                          </div>
                        </td>
                        <td className="px-8 py-6 text-center">
                          <div className="flex flex-col items-center">
                            <span className="font-black text-xl text-neutral-200">{soldier.kills.toLocaleString()}</span>
                            <span className="text-[10px] text-neutral-600 font-bold uppercase">Kills</span>
                          </div>
                        </td>
                        <td className="px-8 py-6 text-left">
                          <button className="p-2 hover:text-red-500 transition-colors">
                            <Crosshair size={18} />
                          </button>
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 bg-red-700 rounded-lg flex items-center justify-center rotate-45">
                  <Shield className="-rotate-45 text-white" size={20} />
                </div>
                <span className="text-xl font-black uppercase">تنظيم الدولة التكتيكي</span>
              </div>
              <p className="text-neutral-500 max-w-sm mb-8">
                نحن لسنا مجرد متجر معدات، نحن مجتمع من النخبة الذين يسعون للتميز والاحترافية في الميدان التكتيكي.
              </p>
              <div className="flex gap-4">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="w-10 h-10 rounded-full bg-white/5 hover:bg-red-700/20 hover:text-red-500 transition-all flex items-center justify-center cursor-pointer border border-white/5">
                    <Zap size={18} />
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-bold mb-6 text-white italic">روابط سريعة</h4>
              <ul className="space-y-4 text-neutral-500 text-sm">
                <li><a href="#" className="hover:text-red-500 transition-colors">الرئيسية</a></li>
                <li><a href="#weapons" className="hover:text-red-500 transition-colors">ترسانة الأسلحة</a></li>
                <li><a href="#leaderboard" className="hover:text-red-500 transition-colors">قائمة النخبة</a></li>
                <li><a href="#" className="hover:text-red-500 transition-colors">اتصل بنا</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6 text-white italic">اتصل بنا</h4>
              <ul className="space-y-4 text-neutral-500 text-sm">
                <li>المنطقة التكتيكية الوسطى</li>
                <li>بروتوكول اتصال مشفر</li>
                <li>support@tactical-org.net</li>
              </ul>
            </div>
          </div>
          <div className="flex flex-col md:flex-row justify-between items-center pt-10 border-t border-white/5 text-neutral-600 text-[10px] font-bold uppercase tracking-[0.2em]">
            <p>© 2026 جميع الحقوق محفوظة لتنظيم الدولة التكتيكي</p>
            <div className="flex gap-8 mt-4 md:mt-0">
              <a href="#" className="hover:text-white transition-colors">سياسة الخصوصية</a>
              <a href="#" className="hover:text-white transition-colors">شروط الخدمة</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            className="fixed inset-0 z-[60] bg-neutral-950 p-8 flex flex-col items-center justify-center gap-8"
          >
            <button 
              className="absolute top-8 right-8 p-2"
              onClick={() => setIsMenuOpen(false)}
            >
              <X size={32} />
            </button>
            <a href="#" onClick={() => setIsMenuOpen(false)} className="text-4xl font-black italic hover:text-red-500 transition-colors">الرئيسية</a>
            <a href="#weapons" onClick={() => setIsMenuOpen(false)} className="text-4xl font-black italic hover:text-red-500 transition-colors">الترسانة</a>
            <a href="#leaderboard" onClick={() => setIsMenuOpen(false)} className="text-4xl font-black italic hover:text-red-500 transition-colors">الجنود</a>
            <button className="mt-8 bg-red-700 text-white px-12 py-4 rounded-full font-black text-xl">المتجر</button>
          </motion.div>
        )}
      </AnimatePresence>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes slow-zoom {
          0% { transform: scale(1); }
          100% { transform: scale(1.1); }
        }
        .animate-slow-zoom {
          animation: slow-zoom 20s infinite alternate ease-in-out;
        }
        * {
          scrollbar-width: thin;
          scrollbar-color: #b91c1c #0a0a0a;
        }
        *::-webkit-scrollbar {
          width: 8px;
        }
        *::-webkit-scrollbar-track {
          background: #0a0a0a;
        }
        *::-webkit-scrollbar-thumb {
          background-color: #b91c1c;
          border-radius: 20px;
          border: 2px solid #0a0a0a;
        }
      `}} />
    </div>
  );
}
